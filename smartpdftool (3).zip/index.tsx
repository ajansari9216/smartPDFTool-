
import { GoogleGenAI, Type, Modality } from "@google/genai";
declare var Cropper: any;
// FIX: Corrected the global variable declaration for jsPDF. The library attaches to `window.jspdf`.
declare var jspdf: any;
declare var showdown: any;
declare var window: any;


document.addEventListener('DOMContentLoaded', () => {
    
    // --- Theme Toggle Logic ---
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;

    const applyTheme = (theme: string) => {
        body.dataset.theme = theme;
        localStorage.setItem('theme', theme);
    };

    const toggleTheme = () => {
        const currentTheme = body.dataset.theme === 'dark' ? 'dark' : 'light';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        applyTheme(newTheme);
    };

    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }

    // --- Load Initial Theme ---
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (savedTheme) {
        applyTheme(savedTheme);
    } else if (prefersDark) {
        applyTheme('dark');
    } else {
        applyTheme('light'); // Default
    }

    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');
    const dropdownToggle = document.getElementById('dropdown-toggle');
    const dropdownMenu = document.getElementById('dropdown-menu');
    const searchBar = document.getElementById('search-bar') as HTMLInputElement;
    const searchResultsContainer = document.getElementById('search-results');

    // --- Tool Data for Search ---
    const tools = [
        // AI Tools
        { name: 'AI Recipe Generator', description: 'Generate creative recipes from the ingredients you have on hand.', target: 'ai-recipe-generator-tool-section' },
        { name: 'AI Image Editor', description: 'Edit images using text prompts. Add filters, remove objects, and more with AI.', target: 'ai-image-editor-tool-section' },
        { name: 'AI Video Generator', description: 'Create a short video from a starting image and an optional text prompt.', target: 'ai-video-generator-tool-section' },

        // PDF Tools
        { name: 'Merge PDF', description: 'Combine multiple PDFs into one. Files are merged in the order they are listed.', target: 'merge-pdf-tool-section' },
        { name: 'Split PDF', description: 'Extract a specific range of pages from a PDF file into a new document.', target: 'split-pdf-tool-section' },
        { name: 'Compress PDF', description: 'Reduce PDF file size for easy sharing, while optimizing for the best possible quality.', target: 'compress-pdf-tool-section' },
        { name: 'PDF to Word', description: 'Convert PDFs to editable Word (.docx) files, preserving the original layout.', target: 'pdf-to-word-tool-section' },
        { name: 'PDF to Image', description: 'Convert each page of a PDF into a high-quality JPG or PNG image file.', target: 'pdf-to-image-tool-section' },
        { name: 'Protect PDF', description: 'Secure your PDF by adding a password, encrypting the file to prevent unauthorized access.', target: 'protect-pdf-tool-section' },
        { name: 'Unlock PDF', description: 'Remove password protection from your PDF files (if you have the password).', target: 'unlock-pdf-tool-section' },
        { name: 'Add Page Numbers', description: 'Easily insert page numbers into your PDF documents with customizable positioning.', target: 'add-page-numbers-tool-section' },
    
        // Image Tools
        { name: 'AI Image Editor', description: 'Edit images using text prompts. Add filters, remove objects, and more with AI.', target: 'ai-image-editor-tool-section' },
        { name: 'AI Video Generator', description: 'Create a short video from a starting image and an optional text prompt.', target: 'ai-video-generator-tool-section' },
        { name: 'Resize Image', description: 'Resize your image by pixel dimensions, while maintaining the aspect ratio.', target: 'resize-image-tool-section' },
        { name: 'Crop Image', description: 'Crop your image by selecting a specific area. Perfect for framing and removing unwanted parts.', target: 'crop-image-tool-section' },
        { name: 'Compress Image', description: 'Make your image files smaller for web and email, balancing file size and visual quality.', target: 'compress-image-tool-section' },
        { name: 'Convert to PNG', description: 'Convert various image formats like JPG or GIF into the versatile PNG format.', target: 'convert-to-png-tool-section' },
        { name: 'Convert to JPG', description: 'Convert images like PNG or GIF into the widely-supported JPG format.', target: 'convert-to-jpg-tool-section' },
        { name: 'Background Remover', description: 'Instantly remove the background from any image with a single click, using AI.', target: 'background-remover-tool-section' },
        { name: 'Image Upscaler', description: 'Increase the resolution of your images using AI, making them larger and clearer. Supports 2x and 4x upscaling.', target: 'image-upscaler-tool-section' },
        
        // Text & Document Tools
        { name: 'Text Case Converter', description: 'Convert text between UPPERCASE, lowercase, Title Case, and more.', target: 'case-converter-tool-section' },
        { name: 'Word Counter', description: 'Count words, characters, sentences, and paragraphs in your text.', target: 'word-counter-tool-section' },
        { name: 'Find & Replace Text', description: 'Search for and replace specific words or phrases in a body of text.', target: 'find-replace-tool-section' },
        { name: 'Keyword Density Checker', description: 'Analyze text to find the density of specific keywords for SEO.', target: 'keyword-density-tool-section' },
        { name: 'Sentence Counter', description: 'Count the total number of sentences in a block of text.', target: 'sentence-counter-tool-section' },
        { name: 'Text Reverser', description: 'Flip any text backward instantly.', target: 'text-reverser-tool-section' },
        { name: 'Sort Lines Alphabetically', description: 'Organize lines of text in alphabetical (A-Z) or reverse order (Z-A).', target: 'sort-lines-tool-section' },
        { name: 'Remove Duplicate Lines', description: 'Delete duplicate lines from a list, leaving only unique entries.', target: 'remove-duplicates-tool-section' },
        { name: 'Paragraph Formatter', description: 'Automatically fix spacing, capitalization, and line breaks in your text.', target: 'paragraph-formatter-tool-section' },
        { name: 'Remove Extra Spaces', description: 'Clean up text by removing duplicate spaces and line breaks.', target: 'remove-spaces-tool-section' },
        { name: 'Text Cleaner', description: 'Remove HTML tags, symbols, and extra spaces from your text.', target: 'text-cleaner-tool-section' },
        { name: 'Random Password Generator', description: 'Create strong, secure, and random passwords for your accounts.', target: 'password-generator-tool-section' },
        { name: 'Notes Saver', description: 'A simple notepad that saves your text to your browser for your next visit.', target: 'notes-saver-tool-section' },
        { name: 'Simple Notepad', description: 'A clean notepad to write and download text as a .txt file.', target: 'simple-notepad-tool-section' },
        { name: 'Lorem Ipsum Generator', description: 'Generate placeholder text for your design mockups.', target: 'lorem-ipsum-tool-section' },
        { name: 'Text Compare', description: 'Compare two text documents and highlight the differences.', target: 'text-compare-tool-section' },
        { name: 'Word Frequency Analyzer', description: 'Analyze text to find the most frequently used words.', target: 'word-frequency-tool-section' },
        { name: 'Text Encrypt / Decrypt', description: 'Encode and decode text using the Base64 method.', target: 'text-encrypt-tool-section' },
        { name: 'Markdown to HTML', description: 'Convert Markdown syntax into valid HTML code.', target: 'markdown-html-tool-section' },
        { name: 'HTML to Text', description: 'Strip HTML tags from a document to get plain text.', target: 'html-text-tool-section' },
        { name: 'Resume Generator', description: 'Fill out a form to create a professional PDF resume.', target: 'resume-generator-tool-section' },
        { name: 'Emoji Remover', description: 'Strip all emojis from your text, leaving only plain text.', target: 'emoji-remover-tool-section' },
    
        // Conversion Tools
        { name: 'Image to PDF', description: 'Combine multiple images (JPG, PNG, etc.) into a single, easy-to-share PDF document.', target: 'image-to-pdf-tool-section' },
        { name: 'Image to Text (OCR)', description: 'Extract text from any image. Convert scanned documents or pictures into editable text.', target: 'image-to-text-tool-section' },
        { name: 'TXT to PDF', description: 'Convert simple .txt files into professional-looking PDF documents.', target: 'txt-to-pdf-tool-section' },
        { name: 'HTML to TXT', description: 'Strip all HTML tags and formatting from a file, leaving only the plain text.', target: 'html-text-tool-section' },
        { name: 'CSV to XLSX', description: 'Effortlessly convert your CSV data files into the Microsoft Excel (.xlsx) format.', target: 'csv-to-xlsx-tool-section' },
    
        // SEO / Writing Helpers
        { name: 'Keyword Generator', description: 'Discover new keyword ideas to improve your SEO and content marketing strategy.', target: 'keyword-generator-tool-section' },
        { name: 'Meta Tag Generator', description: 'Use AI to generate SEO-optimized meta titles, descriptions, and keywords for your content.', target: 'meta-tag-generator-tool-section' },
        { name: 'Plagiarism Checker', description: 'Ensure your content is original by scanning for instances of plagiarism across the internet.', target: 'plagiarism-checker-tool-section' },
        { name: 'Readability Score', description: 'Calculate the readability of your writing to ensure it is easy for your audience to understand.', target: 'readability-score-tool-section' },
        { name: 'AI Title Writer', description: 'Use AI to brainstorm creative and engaging headlines for your blog posts, articles, or videos.', target: 'ai-title-writer-tool-section' },

        // Audio Tools
        { name: 'MP3 to WAV', description: 'Convert compressed MP3 audio to the uncompressed, high-quality WAV format.', target: 'mp3-to-wav-tool-section' },
        { name: 'WAV to MP3', description: 'Convert large, uncompressed WAV files into the smaller, more portable MP3 format.', target: 'wav-to-mp3-tool-section' },
        { name: 'Record Audio', description: 'Record high-quality audio directly from your microphone and save it as a WAV file.', target: 'record-audio-tool-section' },
        { name: 'Audio Trimmer', description: 'Easily cut or trim the beginning and end of your audio files to get the perfect clip.', target: 'audio-trimmer-tool-section' },
        { name: 'Volume Booster', description: 'Amplify the sound of your audio files if they are too quiet, without needing complex software.', target: 'volume-booster-tool-section' },

        // Site Pages
        { name: 'About', description: 'Learn more about SMARTPDFTOOL, our mission, and features.', target: 'about-section' },
        { name: 'Contact', description: 'Get in touch with us with your questions or feedback.', target: 'contact-section' },
        { name: 'Blog', description: 'Tips, tricks, and tutorials for your digital tasks.', target: 'blog-section' },
        { name: 'Frequently Asked Questions (FAQ)', description: 'Find answers to common questions about our tools.', target: 'faq-section' },
        { name: 'How to Compress PDF Without Losing Quality', description: 'A blog post on reducing PDF file size while maintaining quality.', target: 'blog-post-compress-pdf' },
    ];

    // --- Usage Stats Logic ---
    const USAGE_STATS_KEY = 'toolUsageStats';

    function getUsageStats(): { [key: string]: number } {
        try {
            const stats = localStorage.getItem(USAGE_STATS_KEY);
            return stats ? JSON.parse(stats) : {};
        } catch (e) {
            console.error("Failed to parse usage stats from localStorage", e);
            return {};
        }
    }

    function saveUsageStats(stats: { [key: string]: number }) {
        try {
            localStorage.setItem(USAGE_STATS_KEY, JSON.stringify(stats));
        } catch (e) {
            console.error("Failed to save usage stats to localStorage", e);
        }
    }

    function incrementToolUsage(toolId: string) {
        if (!toolId) return;

        const stats = getUsageStats();
        const newCount = (stats[toolId] || 0) + 1;
        stats[toolId] = newCount;
        saveUsageStats(stats);

        // Update the UI in real-time
        document.querySelectorAll<HTMLElement>(`[data-tool-id="${toolId}"]`).forEach(el => {
            el.textContent = newCount.toString();
        });
    }
    
    function updateAllUsageDisplays() {
        const stats = getUsageStats();
        document.querySelectorAll<HTMLElement>('[data-tool-id]').forEach(el => {
            const toolId = el.dataset.toolId;
            if (toolId && stats[toolId]) {
                el.textContent = stats[toolId].toString();
            } else {
                el.textContent = '0'; // Default if not found
            }
        });
    }

    // --- AI Video Generator API Key Check ---
    async function checkVideoGeneratorApiKey() {
        const videoGeneratorKeyPrompt = document.getElementById('ai-video-generator-key-prompt');
        const videoGeneratorMainContent = document.getElementById('ai-video-generator-main-content');
    
        if (!videoGeneratorKeyPrompt || !videoGeneratorMainContent) return;
    
        try {
            const hasKey = await window.aistudio.hasSelectedApiKey();
            if (hasKey) {
                videoGeneratorKeyPrompt.style.display = 'none';
                videoGeneratorMainContent.style.display = 'block';
                return;
            }
        } catch (e) {
            console.error('Error checking for API key:', e);
            // Fallback to showing the prompt if the check fails.
        }
        
        // If we're here, no key is selected or check failed.
        videoGeneratorKeyPrompt.style.display = 'block';
        videoGeneratorMainContent.style.display = 'none';
    }
    

    // Shows a specific section and hides all others
    async function showSection(id) {
        // FIX: Cast the result of querySelectorAll to NodeListOf<HTMLElement> to ensure that the `style` property is available on each `section` element.
        document.querySelectorAll<HTMLElement>('main > section').forEach(section => {
            section.style.display = 'none';
        });
        const targetSection = document.getElementById(id);
        if (targetSection) {
            targetSection.style.display = 'block';
             // Increment usage count for tool pages
            if (targetSection.classList.contains('tool-page')) {
                incrementToolUsage(id);
            }
            // Special handling for tools requiring API key check
            if (id === 'ai-video-generator-tool-section') {
                await checkVideoGeneratorApiKey();
            }
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });

        // Ensure menus are closed after navigation
        if(navMenu) navMenu.classList.remove('active');
        if(dropdownMenu) dropdownMenu.classList.remove('show');
        
        // Clear and hide search results after navigation
        if (searchBar) searchBar.value = '';
        if (searchResultsContainer) searchResultsContainer.style.display = 'none';
    }

    // --- Search Bar Logic ---
    if (searchBar && searchResultsContainer) {
        searchBar.addEventListener('input', () => {
            const query = searchBar.value.trim().toLowerCase();
            
            if (query.length > 0) {
                // Scoring function to determine relevance
                const calculateScore = (tool, searchQuery) => {
                    const name = tool.name.toLowerCase();
                    const description = tool.description.toLowerCase();
                    let score = 0;

                    // Exact match bonus (very high score)
                    if (name === searchQuery) {
                        score += 100;
                    }

                    // Higher score for matches in the name
                    if (name.includes(searchQuery)) {
                        score += 10;
                    }

                    // Bonus score if the name starts with the query
                    if (name.startsWith(searchQuery)) {
                        score += 5;
                    }

                    // Lower score for matches in the description
                    if (description.includes(searchQuery)) {
                        score += 2;
                    }
                    
                    // Simple "fuzzy" search by checking for individual words
                    // This helps if the user types "pdf merge" instead of "merge pdf"
                    const queryWords = searchQuery.split(' ').filter(w => w.length > 1);
                    if (queryWords.length > 1) {
                        queryWords.forEach(word => {
                            if (name.includes(word)) {
                                score += 3;
                            }
                            if (description.includes(word)) {
                                score += 1;
                            }
                        });
                    }

                    return score;
                };

                const scoredResults = tools
                    .map(tool => ({
                        ...tool,
                        score: calculateScore(tool, query)
                    }))
                    .filter(tool => tool.score > 0)
                    .sort((a, b) => b.score - a.score);
                
                renderSearchResults(scoredResults);
            } else {
                searchResultsContainer.style.display = 'none';
            }
        });
    }

    function renderSearchResults(results) {
        if (!searchResultsContainer) return;
        
        searchResultsContainer.innerHTML = ''; // Clear previous results

        if (results.length === 0) {
            searchResultsContainer.innerHTML = '<div class="search-no-results">No tools found</div>';
        } else {
            results.forEach(tool => {
                const item = document.createElement('div');
                item.className = 'search-result-item spa-link';
                item.dataset.target = tool.target;
                item.innerHTML = `<strong>${tool.name}</strong><p>${tool.description}</p>`;
                searchResultsContainer.appendChild(item);
            });
        }
        searchResultsContainer.style.display = 'block';
    }


    // --- SPA Navigation via Event Delegation ---
    // A single, smart listener on the body handles all navigation clicks.
    document.body.addEventListener('click', (event) => {
        // Find the closest ancestor element that has the .spa-link class
        const link = (event.target as HTMLElement).closest('.spa-link');

        if (link) {
            // Prevent default link behavior if it's an actual <a> tag
            if (link.tagName === 'A') {
                 event.preventDefault();
            }

            const targetId = (link as HTMLElement).dataset.target;
            if (targetId) {
                showSection(targetId);
            }
        }
    });

    // --- Menu Logic ---

    // Toggle mobile menu
    if(hamburger) {
        hamburger.addEventListener('click', () => {
            if(navMenu) navMenu.classList.toggle('active');
        });
    }

    // Toggle dropdown menu
    if(dropdownToggle) {
        dropdownToggle.addEventListener('click', (event) => {
            event.stopPropagation(); // Prevent the window click listener from closing it immediately
            if(dropdownMenu) dropdownMenu.classList.toggle('show');
        });
    }


    // Close dropdowns/search if clicking anywhere else on the page
    window.addEventListener('click', (event) => {
        if (dropdownToggle && dropdownMenu && !dropdownToggle.contains(event.target as Node) && !dropdownMenu.contains(event.target as Node)) {
            dropdownMenu.classList.remove('show');
        }

        if (searchResultsContainer && searchBar && !searchBar.contains(event.target as Node) && !searchResultsContainer.contains(event.target as Node)) {
            searchResultsContainer.style.display = 'none';
        }
    });

    // --- Loading Overlay Helpers ---
    function showToolLoadingOverlay(containerEl: HTMLElement | null, message = 'Processing...') {
        if (!containerEl) return;
        // Remove existing overlay first
        hideToolLoadingOverlay(containerEl);

        const overlay = document.createElement('div');
        overlay.className = 'tool-loading-overlay';
        overlay.innerHTML = `
            <div class="loading-overlay-content">
                <div class="loader"></div>
                <p>${message}</p>
            </div>
        `;
        containerEl.style.position = 'relative'; // Ensure overlay is positioned correctly
        containerEl.appendChild(overlay);
    }

    function updateToolLoadingOverlayMessage(containerEl: HTMLElement | null, message: string) {
        if (!containerEl) return;
        const p = containerEl.querySelector('.tool-loading-overlay p') as HTMLParagraphElement;
        if (p) {
            p.textContent = message;
        }
    }


    function hideToolLoadingOverlay(containerEl: HTMLElement | null) {
        if (!containerEl) return;
        const overlay = containerEl.querySelector('.tool-loading-overlay');
        if (overlay) {
            containerEl.removeChild(overlay);
        }
    }

    // --- Generic Drag and Drop Helper ---
    // FIX: The initial value for the `reduce` method was missing the `element` property, causing a TypeScript error.
    // The accumulator type is now explicitly defined and the initial value is updated to match, ensuring type safety.
    function getDragAfterElement(container: HTMLElement, y: number): HTMLElement | null {
        const draggableElements = [...container.querySelectorAll('li:not(.dragging)') as NodeListOf<HTMLElement>];
    
        return draggableElements.reduce<{ offset: number; element: HTMLElement | null }>((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if (offset < 0 && offset > closest.offset) {
                return { offset: offset, element: child };
            } else {
                return closest;
            }
        }, { offset: Number.NEGATIVE_INFINITY, element: null }).element;
    }

    /**
     * Formats bytes into a human-readable string (KB, MB, GB, etc.).
     * @param bytes The number of bytes.
     * @param decimals The number of decimal places to use.
     * @returns A formatted string representing the file size.
     */
    function formatBytes(bytes: number, decimals = 2): string {
        if (bytes === 0) return '0 Bytes';
    
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    
        const i = Math.floor(Math.log(bytes) / Math.log(k));
    
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    /**
     * Converts a Blob object to a base64 string, stripping the data URL prefix.
     * @param blob The Blob or File object to convert.
     * @returns A promise that resolves with the base64 encoded string.
     */
    function blobToBase64(blob: Blob): Promise<string> {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = (reader.result as string)?.split(',')[1];
                if (base64String) {
                    resolve(base64String);
                } else {
                    reject(new Error("Failed to read blob as base64."));
                }
            };
            reader.onerror = (error) => reject(error);
            reader.readAsDataURL(blob);
        });
    }

    // --- Merge PDF Tool Logic ---
    const mergePdfDropzone = document.getElementById('merge-pdf-dropzone');
    const mergePdfInput = document.getElementById('merge-pdf-input') as HTMLInputElement;
    const mergePdfBrowseBtn = document.getElementById('merge-pdf-browse-btn');
    const mergePdfFileListContainer = document.getElementById('merge-pdf-file-list-container');
    const mergePdfFileListEl = document.getElementById('merge-pdf-file-list');
    const mergePdfActionBtn = document.getElementById('merge-pdf-action-btn') as HTMLButtonElement;
    const mergePdfClearAllBtn = document.getElementById('merge-pdf-clear-all-btn') as HTMLButtonElement;
    const mergePdfResultEl = document.getElementById('merge-pdf-result');

    let mergeFiles: File[] = [];

    function renderMergeFileList() {
        if (!mergePdfFileListEl || !mergePdfActionBtn) return;
        
        mergePdfFileListEl.innerHTML = '';
        if (mergeFiles.length > 0) {
            mergeFiles.forEach((file, index) => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <span class="file-name">${file.name}</span>
                    <button class="remove-file-btn" data-index="${index}" aria-label="Remove ${file.name}" title="Remove this file">&times;</button>
                `;
                mergePdfFileListEl.appendChild(li);
            });
        }

        // Add event listeners to new remove buttons
        mergePdfFileListEl.querySelectorAll('.remove-file-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const indexToRemove = parseInt((event.currentTarget as HTMLElement).dataset.index!, 10);
                mergeFiles.splice(indexToRemove, 1);
                renderMergeFileList();
            });
        });
        
        // Enable/disable merge button
        mergePdfActionBtn.disabled = mergeFiles.length < 2;
        if (mergePdfClearAllBtn) {
            mergePdfClearAllBtn.style.display = mergeFiles.length > 0 ? 'inline-block' : 'none';
        }
    }
    
    function handleMergeFiles(files: FileList) {
        const newFiles = Array.from(files).filter(file => 
            file.type === 'application/pdf' && 
            !mergeFiles.some(existingFile => existingFile.name === file.name && existingFile.size === file.size)
        );
        mergeFiles.push(...newFiles);
        renderMergeFileList();
    }
    
    if (mergePdfDropzone && mergePdfInput) {
        mergePdfDropzone.addEventListener('click', () => mergePdfInput.click());
        
        mergePdfDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            mergePdfDropzone.classList.add('dragover');
        });

        mergePdfDropzone.addEventListener('dragleave', () => {
            mergePdfDropzone.classList.remove('dragover');
        });

        mergePdfDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            mergePdfDropzone.classList.remove('dragover');
            if (e.dataTransfer?.files) {
                handleMergeFiles(e.dataTransfer.files);
            }
        });
    }
    
    if (mergePdfFileListContainer) {
        mergePdfFileListContainer.addEventListener('dragover', (e) => {
            e.preventDefault();
            mergePdfFileListContainer.classList.add('dragover');
        });
        mergePdfFileListContainer.addEventListener('dragleave', () => {
            mergePdfFileListContainer.classList.remove('dragover');
        });
        mergePdfFileListContainer.addEventListener('drop', (e) => {
            e.preventDefault();
            mergePdfFileListContainer.classList.remove('dragover');
            if (e.dataTransfer?.files) {
                handleMergeFiles(e.dataTransfer.files);
            }
        });
    }

    if (mergePdfBrowseBtn && mergePdfInput) {
        mergePdfBrowseBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // prevent dropzone click handler
            mergePdfInput.click();
        });
    }

    if (mergePdfInput) {
        mergePdfInput.addEventListener('change', () => {
            if (mergePdfInput.files) {
                handleMergeFiles(mergePdfInput.files);
                mergePdfInput.value = ''; // Reset input to allow re-selecting the same file
            }
        });
    }
    
    if (mergePdfClearAllBtn) {
        mergePdfClearAllBtn.addEventListener('click', () => {
            mergeFiles = [];
            renderMergeFileList();
        });
    }
    
    if (mergePdfActionBtn) {
        mergePdfActionBtn.addEventListener('click', async () => {
            if (!mergePdfResultEl) return;
            
            mergePdfResultEl.style.display = 'none';
            mergePdfActionBtn.disabled = true;

            if (mergePdfFileListEl) {
                const listItems = mergePdfFileListEl.children;
                for (let i = 0; i < listItems.length; i++) {
                    const li = listItems[i] as HTMLElement;
                    const file = mergeFiles[i];
                    if (file) {
                        li.innerHTML = `
                            <span class="file-name">${file.name}</span>
                            <div class="file-status">
                                <div class="spinner-inline"></div>
                                <span>Processing...</span>
                            </div>
                        `;
                    }
                }
            }

            // Simulate API call/processing
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            mergePdfResultEl.style.display = 'block';
            mergePdfResultEl.innerHTML = `
                <p>✅ PDFs merged successfully!</p>
                <a href="#" download="merged.pdf">Download Merged PDF</a>
            `;

            // Reset
            mergeFiles = [];
            renderMergeFileList();
        });
    }

    // --- Split PDF Tool Logic ---
    const splitPdfDropzoneContainer = document.getElementById('split-pdf-dropzone-container');
    const splitPdfDropzone = document.getElementById('split-pdf-dropzone');
    const splitPdfInput = document.getElementById('split-pdf-input') as HTMLInputElement;
    const splitPdfBrowseBtn = document.getElementById('split-pdf-browse-btn');
    const splitPdfOptionsContainer = document.getElementById('split-pdf-options-container');
    const splitPdfFileNameEl = document.getElementById('split-pdf-file-name');
    const splitPdfPageCountEl = document.getElementById('split-pdf-page-count');
    const splitPdfClearBtn = document.getElementById('split-pdf-clear-btn');
    const splitPdfFromInput = document.getElementById('split-pdf-from') as HTMLInputElement;
    const splitPdfToInput = document.getElementById('split-pdf-to') as HTMLInputElement;
    const splitPdfActionBtn = document.getElementById('split-pdf-action-btn') as HTMLButtonElement;
    const splitPdfResultEl = document.getElementById('split-pdf-result');
    const splitPdfToolContainer = document.querySelector('#split-pdf-tool-section .tool-container') as HTMLElement;
    const splitPdfErrorEl = document.getElementById('split-pdf-error');


    let splitFile: File | null = null;
    let totalPages = 0;

    function validateSplitInputs() {
        if (!splitPdfActionBtn || !splitPdfFromInput || !splitPdfToInput || !splitPdfErrorEl) return;
    
        const fromValue = splitPdfFromInput.value;
        const toValue = splitPdfToInput.value;
        const fromPage = parseInt(fromValue, 10);
        const toPage = parseInt(toValue, 10);
        
        let errorMessage = '';
    
        if (fromValue && (isNaN(fromPage) || fromPage < 1)) {
            errorMessage = "'From' page must be a positive number.";
        } else if (toValue && (isNaN(toPage) || toPage < 1)) {
            errorMessage = "'To' page must be a positive number.";
        } else if (fromValue && fromPage > totalPages) {
            errorMessage = `'From' page cannot be greater than the total of ${totalPages} pages.`;
        } else if (toValue && toPage > totalPages) {
            errorMessage = `'To' page cannot be greater than the total of ${totalPages} pages.`;
        } else if (fromValue && toValue && !isNaN(fromPage) && !isNaN(toPage) && fromPage > toPage) {
            errorMessage = `'From' page must be less than or equal to the 'To' page.`;
        }
    
        if (errorMessage) {
            splitPdfErrorEl.textContent = errorMessage;
            splitPdfErrorEl.style.display = 'block';
            splitPdfActionBtn.disabled = true;
        } else {
            splitPdfErrorEl.style.display = 'none';
            // The button should only be enabled if everything is valid
            const isValid =
                splitFile !== null &&
                fromValue !== '' &&
                toValue !== '' &&
                !isNaN(fromPage) &&
                !isNaN(toPage) &&
                fromPage >= 1 &&
                toPage <= totalPages &&
                fromPage <= toPage;
            splitPdfActionBtn.disabled = !isValid;
        }
    }

    function resetSplitTool() {
        splitFile = null;
        totalPages = 0;
        if (splitPdfInput) splitPdfInput.value = ''; // Reset file input
        
        if (splitPdfDropzoneContainer) splitPdfDropzoneContainer.style.display = 'block';
        if (splitPdfOptionsContainer) splitPdfOptionsContainer.style.display = 'none';
        if(splitPdfActionBtn) splitPdfActionBtn.disabled = true;
        if(splitPdfResultEl) {
            splitPdfResultEl.style.display = 'none';
            splitPdfResultEl.innerHTML = '';
        }
        if(splitPdfErrorEl) {
            splitPdfErrorEl.style.display = 'none';
            splitPdfErrorEl.textContent = '';
        }
        validateSplitInputs();
    }

    function handleSplitFile(file: File | undefined) {
        if (!file || file.type !== 'application/pdf') {
            alert('Please select a valid PDF file.');
            return;
        }
        splitFile = file;

        if (!splitPdfDropzoneContainer || !splitPdfOptionsContainer || !splitPdfFileNameEl || !splitPdfPageCountEl || !splitPdfFromInput || !splitPdfToInput) return;

        splitPdfDropzoneContainer.style.display = 'none';
        splitPdfOptionsContainer.style.display = 'block';

        splitPdfFileNameEl.textContent = splitFile.name;
        // Simulate reading PDF and getting page count
        totalPages = Math.floor(Math.random() * (50 - 2 + 1)) + 2; // Random pages between 2 and 50
        splitPdfPageCountEl.textContent = `${totalPages} pages detected`;

        splitPdfFromInput.value = '1';
        splitPdfToInput.value = totalPages.toString();
        splitPdfFromInput.max = totalPages.toString();
        splitPdfToInput.max = totalPages.toString();
        splitPdfFromInput.min = '1';
        splitPdfToInput.min = '1';

        validateSplitInputs();
    }

    if (splitPdfDropzone && splitPdfInput) {
        splitPdfDropzone.addEventListener('click', () => splitPdfInput.click());
        
        splitPdfDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            splitPdfDropzone.classList.add('dragover');
        });

        splitPdfDropzone.addEventListener('dragleave', () => {
            splitPdfDropzone.classList.remove('dragover');
        });

        splitPdfDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            splitPdfDropzone.classList.remove('dragover');
            if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
                handleSplitFile(e.dataTransfer.files[0]);
            }
        });
    }

    if (splitPdfBrowseBtn && splitPdfInput) {
        splitPdfBrowseBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // prevent dropzone click handler
            splitPdfInput.click();
        });
    }

    if (splitPdfInput) {
        splitPdfInput.addEventListener('change', () => {
            if (splitPdfInput.files && splitPdfInput.files.length > 0) {
                handleSplitFile(splitPdfInput.files[0]);
            }
        });
    }

    if (splitPdfClearBtn) {
        splitPdfClearBtn.addEventListener('click', resetSplitTool);
    }

    if (splitPdfFromInput && splitPdfToInput) {
        splitPdfFromInput.addEventListener('input', validateSplitInputs);
        splitPdfToInput.addEventListener('input', validateSplitInputs);
    }

    if (splitPdfActionBtn) {
        splitPdfActionBtn.addEventListener('click', async () => {
            if (!splitPdfResultEl || !splitFile) return;
            
            showToolLoadingOverlay(splitPdfToolContainer, 'Splitting your PDF...');
            splitPdfResultEl.style.display = 'none';
            splitPdfActionBtn.disabled = true;

            // Simulate API call/processing
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            const from = splitPdfFromInput.value;
            const to = splitPdfToInput.value;
            const originalName = splitFile.name.replace(/\.pdf$/i, '');
            const downloadName = `${originalName}_pages_${from}-${to}.pdf`;

            hideToolLoadingOverlay(splitPdfToolContainer);
            splitPdfResultEl.style.display = 'block';
            splitPdfResultEl.innerHTML = `
                <p>✅ PDF split successfully!</p>
                <a href="#" download="${downloadName}">Download Pages ${from}-${to}</a>
            `;
        });
    }

    // --- Compress PDF Tool Logic ---
    const compressPdfDropzone = document.getElementById('compress-pdf-dropzone');
    const compressPdfInput = document.getElementById('compress-pdf-input') as HTMLInputElement;
    const compressPdfBrowseBtn = document.getElementById('compress-pdf-browse-btn');
    const compressPdfFileListContainer = document.getElementById('compress-pdf-file-list-container');
    const compressPdfFileListEl = document.getElementById('compress-pdf-file-list');
    const compressPdfActionBtn = document.getElementById('compress-pdf-action-btn') as HTMLButtonElement;
    const compressPdfClearAllBtn = document.getElementById('compress-pdf-clear-all-btn') as HTMLButtonElement;
    const compressPdfResultEl = document.getElementById('compress-pdf-result');

    let compressFiles: File[] = [];

    function resetCompressTool() {
        compressFiles = [];
        if (compressPdfInput) compressPdfInput.value = '';
        if (compressPdfResultEl) {
            compressPdfResultEl.style.display = 'none';
            compressPdfResultEl.innerHTML = '';
        }
        if (compressPdfActionBtn.parentElement) {
            (compressPdfActionBtn.parentElement as HTMLElement).style.display = 'flex';
        }
        
        renderCompressFileList();
    }

    function renderCompressFileList() {
        if (!compressPdfFileListEl || !compressPdfActionBtn) return;
        
        compressPdfFileListEl.innerHTML = '';
        if (compressFiles.length > 0) {
            compressFiles.forEach((file, index) => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <span class="file-name">${file.name}</span>
                    <button class="remove-file-btn" data-index="${index}" aria-label="Remove ${file.name}" title="Remove this file">&times;</button>
                `;
                compressPdfFileListEl.appendChild(li);
            });
        }

        compressPdfFileListEl.querySelectorAll('.remove-file-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const indexToRemove = parseInt((event.currentTarget as HTMLElement).dataset.index!, 10);
                compressFiles.splice(indexToRemove, 1);
                renderCompressFileList();
            });
        });
        
        if (compressPdfFileListContainer) {
            compressPdfFileListContainer.style.display = compressFiles.length > 0 ? 'block' : 'none';
        }

        compressPdfActionBtn.disabled = compressFiles.length === 0;
        if (compressPdfClearAllBtn) {
            compressPdfClearAllBtn.style.display = compressFiles.length > 0 ? 'inline-block' : 'none';
        }
    }

    function handleCompressFiles(files: FileList) {
        const newFiles = Array.from(files).filter(file => 
            file.type === 'application/pdf' && 
            !compressFiles.some(existingFile => existingFile.name === file.name && existingFile.size === file.size)
        );
        compressFiles.push(...newFiles);
        renderCompressFileList();
    }

    if (compressPdfDropzone && compressPdfInput) {
        compressPdfDropzone.addEventListener('click', () => compressPdfInput.click());
        
        compressPdfDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            compressPdfDropzone.classList.add('dragover');
        });

        compressPdfDropzone.addEventListener('dragleave', () => {
            compressPdfDropzone.classList.remove('dragover');
        });

        compressPdfDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            compressPdfDropzone.classList.remove('dragover');
            if (e.dataTransfer?.files) {
                handleCompressFiles(e.dataTransfer.files);
            }
        });
    }

    if (compressPdfFileListContainer) {
        compressPdfFileListContainer.addEventListener('dragover', (e) => {
            e.preventDefault();
            compressPdfFileListContainer.classList.add('dragover');
        });
        compressPdfFileListContainer.addEventListener('dragleave', () => {
            compressPdfFileListContainer.classList.remove('dragover');
        });
        compressPdfFileListContainer.addEventListener('drop', (e) => {
            e.preventDefault();
            compressPdfFileListContainer.classList.remove('dragover');
            if (e.dataTransfer?.files) {
                handleCompressFiles(e.dataTransfer.files);
            }
        });
    }

    if (compressPdfBrowseBtn && compressPdfInput) {
        compressPdfBrowseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            compressPdfInput.click();
        });
    }

    if (compressPdfInput) {
        compressPdfInput.addEventListener('change', () => {
            if (compressPdfInput.files) {
                handleCompressFiles(compressPdfInput.files);
                compressPdfInput.value = '';
            }
        });
    }
    
    if (compressPdfClearAllBtn) {
        compressPdfClearAllBtn.addEventListener('click', () => {
            compressFiles = [];
            renderCompressFileList();
        });
    }
    
    if (compressPdfActionBtn) {
        compressPdfActionBtn.addEventListener('click', async () => {
            if (!compressPdfResultEl || !compressPdfFileListEl || !compressPdfFileListContainer) return;
            
            compressPdfResultEl.style.display = 'none';
            compressPdfActionBtn.disabled = true;

            if (compressPdfFileListEl) {
                const listItems = compressPdfFileListEl.children;
                for (let i = 0; i < listItems.length; i++) {
                    const li = listItems[i] as HTMLElement;
                    const file = compressFiles[i];
                    if (file) {
                        li.innerHTML = `
                            <span class="file-name">${file.name}</span>
                            <div class="file-status">
                                <div class="spinner-inline"></div>
                                <span>Compressing...</span>
                            </div>
                        `;
                    }
                }
            }

            await new Promise(resolve => setTimeout(resolve, 2000));
            
            let resultsHtml = `
                <p class="result-success-message">✅ ${compressFiles.length} file(s) compressed successfully!</p>
                <table class="result-table">
                    <thead>
                        <tr>
                            <th>File Name</th>
                            <th>Original Size</th>
                            <th>New Size</th>
                            <th>Reduction</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            compressFiles.forEach(file => {
                const originalSize = file.size;
                const newSize = originalSize * (Math.random() * 0.4 + 0.3); // Simulate 30-70% reduction
                const reduction = 100 - (newSize / originalSize * 100);
                
                resultsHtml += `
                    <tr>
                        <td>${file.name}</td>
                        <td>${formatBytes(originalSize)}</td>
                        <td>${formatBytes(newSize)}</td>
                        <td class="reduction-cell">${reduction.toFixed(0)}%</td>
                    </tr>
                `;
            });
            
            resultsHtml += `
                    </tbody>
                </table>
                <div class="tool-actions">
                    <a href="#" download="compressed_files.zip" class="btn">
                       <i class="fas fa-download"></i> Download All (.zip)
                    </a>
                    <button id="compress-pdf-again-btn" class="btn-secondary">
                        Compress More Files
                    </button>
                </div>
            `;

            compressPdfFileListContainer.style.display = 'none';
            if (compressPdfActionBtn.parentElement) (compressPdfActionBtn.parentElement as HTMLElement).style.display = 'none';
            
            compressPdfResultEl.innerHTML = resultsHtml;
            compressPdfResultEl.style.display = 'block';

            document.getElementById('compress-pdf-again-btn')?.addEventListener('click', resetCompressTool);
        });
    }

    // --- PDF to Word Tool Logic ---
    const pdfToWordDropzone = document.getElementById('pdf-to-word-dropzone');
    const pdfToWordInput = document.getElementById('pdf-to-word-input') as HTMLInputElement;
    const pdfToWordBrowseBtn = document.getElementById('pdf-to-word-browse-btn');
    const pdfToWordFileListContainer = document.getElementById('pdf-to-word-file-list-container');
    const pdfToWordFileListEl = document.getElementById('pdf-to-word-file-list');
    const pdfToWordActionBtn = document.getElementById('pdf-to-word-action-btn') as HTMLButtonElement;
    const pdfToWordClearAllBtn = document.getElementById('pdf-to-word-clear-all-btn') as HTMLButtonElement;
    const pdfToWordResultEl = document.getElementById('pdf-to-word-result');

    let pdfToWordFiles: File[] = [];

    function renderPdfToWordFileList() {
        if (!pdfToWordFileListEl || !pdfToWordActionBtn) return;
        
        pdfToWordFileListEl.innerHTML = '';
        if (pdfToWordFiles.length > 0) {
            pdfToWordFiles.forEach((file, index) => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <span class="file-name">${file.name}</span>
                    <button class="remove-file-btn" data-index="${index}" aria-label="Remove ${file.name}" title="Remove this file">&times;</button>
                `;
                pdfToWordFileListEl.appendChild(li);
            });
        }

        pdfToWordFileListEl.querySelectorAll('.remove-file-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const indexToRemove = parseInt((event.currentTarget as HTMLElement).dataset.index!, 10);
                pdfToWordFiles.splice(indexToRemove, 1);
                renderPdfToWordFileList();
            });
        });
        
        pdfToWordActionBtn.disabled = pdfToWordFiles.length === 0;
        if (pdfToWordClearAllBtn) {
            pdfToWordClearAllBtn.style.display = pdfToWordFiles.length > 0 ? 'inline-block' : 'none';
        }
    }

    function handlePdfToWordFiles(files: FileList) {
        const newFiles = Array.from(files).filter(file => 
            file.type === 'application/pdf' && 
            !pdfToWordFiles.some(existingFile => existingFile.name === file.name && existingFile.size === file.size)
        );
        pdfToWordFiles.push(...newFiles);
        renderPdfToWordFileList();
    }

    if (pdfToWordDropzone && pdfToWordInput) {
        pdfToWordDropzone.addEventListener('click', () => pdfToWordInput.click());
        
        pdfToWordDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            pdfToWordDropzone.classList.add('dragover');
        });

        pdfToWordDropzone.addEventListener('dragleave', () => {
            pdfToWordDropzone.classList.remove('dragover');
        });

        pdfToWordDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            pdfToWordDropzone.classList.remove('dragover');
            if (e.dataTransfer?.files) {
                handlePdfToWordFiles(e.dataTransfer.files);
            }
        });
    }

    if (pdfToWordFileListContainer) {
        pdfToWordFileListContainer.addEventListener('dragover', (e) => {
            e.preventDefault();
            pdfToWordFileListContainer.classList.add('dragover');
        });
        pdfToWordFileListContainer.addEventListener('dragleave', () => {
            pdfToWordFileListContainer.classList.remove('dragover');
        });
        pdfToWordFileListContainer.addEventListener('drop', (e) => {
            e.preventDefault();
            pdfToWordFileListContainer.classList.remove('dragover');
            if (e.dataTransfer?.files) {
                handlePdfToWordFiles(e.dataTransfer.files);
            }
        });
    }

    if (pdfToWordBrowseBtn && pdfToWordInput) {
        pdfToWordBrowseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            pdfToWordInput.click();
        });
    }

    if (pdfToWordInput) {
        pdfToWordInput.addEventListener('change', () => {
            if (pdfToWordInput.files) {
                handlePdfToWordFiles(pdfToWordInput.files);
                pdfToWordInput.value = '';
            }
        });
    }
    
    if (pdfToWordClearAllBtn) {
        pdfToWordClearAllBtn.addEventListener('click', () => {
            pdfToWordFiles = [];
            renderPdfToWordFileList();
        });
    }
    
    if (pdfToWordActionBtn) {
        pdfToWordActionBtn.addEventListener('click', async () => {
            if (!pdfToWordResultEl) return;
            
            pdfToWordResultEl.style.display = 'none';
            pdfToWordActionBtn.disabled = true;

            if (pdfToWordFileListEl) {
                const listItems = pdfToWordFileListEl.children;
                for (let i = 0; i < listItems.length; i++) {
                    const li = listItems[i] as HTMLElement;
                    const file = pdfToWordFiles[i];
                    if (file) {
                        li.innerHTML = `
                            <span class="file-name">${file.name}</span>
                            <div class="file-status">
                                <div class="spinner-inline"></div>
                                <span>Converting...</span>
                            </div>
                        `;
                    }
                }
            }

            await new Promise(resolve => setTimeout(resolve, 2000));
            
            pdfToWordResultEl.style.display = 'block';
            pdfToWordResultEl.innerHTML = `
                <p>✅ PDFs converted to Word successfully!</p>
                <a href="#" download="converted.zip">Download Word Document(s)</a>
            `;

            pdfToWordFiles = [];
            renderPdfToWordFileList();
        });
    }

    // --- Protect PDF Tool Logic ---
    const protectPdfDropzone = document.getElementById('protect-pdf-dropzone');
    const protectPdfInput = document.getElementById('protect-pdf-input') as HTMLInputElement;
    const protectPdfBrowseBtn = document.getElementById('protect-pdf-browse-btn');
    const protectPdfFileListContainer = document.getElementById('protect-pdf-file-list-container');
    const protectPdfFileListEl = document.getElementById('protect-pdf-file-list');
    const protectPdfPasswordInput = document.getElementById('protect-pdf-password') as HTMLInputElement;
    const protectPdfPasswordConfirmInput = document.getElementById('protect-pdf-password-confirm') as HTMLInputElement;
    const protectPdfPasswordErrorEl = document.getElementById('protect-pdf-password-error');
    const protectPdfActionBtn = document.getElementById('protect-pdf-action-btn') as HTMLButtonElement;
    const protectPdfClearAllBtn = document.getElementById('protect-pdf-clear-all-btn') as HTMLButtonElement;
    const protectPdfResultEl = document.getElementById('protect-pdf-result');

    let protectFiles: File[] = [];

    function validateProtectInputs() {
        if (!protectPdfActionBtn || !protectPdfPasswordInput || !protectPdfPasswordConfirmInput || !protectPdfPasswordErrorEl) return;
        
        const password = protectPdfPasswordInput.value;
        const confirmPassword = protectPdfPasswordConfirmInput.value;
        let error = "";
        let isValid = true;

        if (password && confirmPassword && password !== confirmPassword) {
            error = "Passwords do not match.";
            isValid = false;
        } else {
            error = "";
        }

        protectPdfPasswordErrorEl.textContent = error;
        protectPdfActionBtn.disabled = !(protectFiles.length > 0 && password && isValid);
    }

    function renderProtectFileList() {
        if (!protectPdfFileListEl) return;
        
        protectPdfFileListEl.innerHTML = '';
        if (protectFiles.length > 0) {
            protectFiles.forEach((file, index) => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <span class="file-name">${file.name}</span>
                    <button class="remove-file-btn" data-index="${index}" aria-label="Remove ${file.name}" title="Remove this file">&times;</button>
                `;
                protectPdfFileListEl.appendChild(li);
            });
        }

        protectPdfFileListEl.querySelectorAll('.remove-file-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const indexToRemove = parseInt((event.currentTarget as HTMLElement).dataset.index!, 10);
                protectFiles.splice(indexToRemove, 1);
                renderProtectFileList();
            });
        });
        
        if (protectPdfClearAllBtn) {
            protectPdfClearAllBtn.style.display = protectFiles.length > 0 ? 'inline-block' : 'none';
        }
        validateProtectInputs();
    }

    function handleProtectFiles(files: FileList) {
        const newFiles = Array.from(files).filter(file => 
            file.type === 'application/pdf' && 
            !protectFiles.some(existingFile => existingFile.name === file.name && existingFile.size === file.size)
        );
        protectFiles.push(...newFiles);
        renderProtectFileList();
    }

    if (protectPdfDropzone && protectPdfInput) {
        protectPdfDropzone.addEventListener('click', () => protectPdfInput.click());
        
        protectPdfDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            protectPdfDropzone.classList.add('dragover');
        });

        protectPdfDropzone.addEventListener('dragleave', () => {
            protectPdfDropzone.classList.remove('dragover');
        });

        protectPdfDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            protectPdfDropzone.classList.remove('dragover');
            if (e.dataTransfer?.files) {
                handleProtectFiles(e.dataTransfer.files);
            }
        });
    }
    
    if (protectPdfFileListContainer) {
        protectPdfFileListContainer.addEventListener('dragover', (e) => {
            e.preventDefault();
            protectPdfFileListContainer.classList.add('dragover');
        });
        protectPdfFileListContainer.addEventListener('dragleave', () => {
            protectPdfFileListContainer.classList.remove('dragover');
        });
        protectPdfFileListContainer.addEventListener('drop', (e) => {
            e.preventDefault();
            protectPdfFileListContainer.classList.remove('dragover');
            if (e.dataTransfer?.files) {
                handleProtectFiles(e.dataTransfer.files);
            }
        });
    }

    if (protectPdfBrowseBtn && protectPdfInput) {
        protectPdfBrowseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            protectPdfInput.click();
        });
    }

    if (protectPdfInput) {
        protectPdfInput.addEventListener('change', () => {
            if (protectPdfInput.files) {
                handleProtectFiles(protectPdfInput.files);
                protectPdfInput.value = '';
            }
        });
    }
    
    if (protectPdfClearAllBtn) {
        protectPdfClearAllBtn.addEventListener('click', () => {
            protectFiles = [];
            renderProtectFileList();
        });
    }
    
    if (protectPdfPasswordInput && protectPdfPasswordConfirmInput) {
        protectPdfPasswordInput.addEventListener('input', validateProtectInputs);
        protectPdfPasswordConfirmInput.addEventListener('input', validateProtectInputs);
    }

    document.querySelectorAll('.password-toggle').forEach(toggle => {
        toggle.addEventListener('click', () => {
            const input = toggle.previousElementSibling as HTMLInputElement;
            const icon = toggle.querySelector('i');
            if (input && icon) {
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            }
        });
    });

    if (protectPdfActionBtn) {
        protectPdfActionBtn.addEventListener('click', async () => {
            if (!protectPdfResultEl || !protectPdfPasswordInput || !protectPdfPasswordConfirmInput || !protectPdfPasswordErrorEl) return;
            
            protectPdfResultEl.style.display = 'none';
            protectPdfActionBtn.disabled = true;

            if (protectPdfFileListEl) {
                const listItems = protectPdfFileListEl.children;
                for (let i = 0; i < listItems.length; i++) {
                    const li = listItems[i] as HTMLElement;
                    const file = protectFiles[i];
                    if (file) {
                        li.innerHTML = `
                            <span class="file-name">${file.name}</span>
                            <div class="file-status">
                                <div class="spinner-inline"></div>
                                <span>Encrypting...</span>
                            </div>
                        `;
                    }
                }
            }

            await new Promise(resolve => setTimeout(resolve, 2000));
            
            protectPdfResultEl.style.display = 'block';
            protectPdfResultEl.innerHTML = `
                <p>✅ PDFs protected successfully!</p>
                <a href="#" download="protected.zip">Download Protected PDF(s)</a>
            `;

            protectFiles = [];
            protectPdfPasswordInput.value = '';
            protectPdfPasswordConfirmInput.value = '';
            protectPdfPasswordErrorEl.textContent = '';
            renderProtectFileList();
        });
    }

    // --- PDF to Image Tool Logic ---
    const pdfToImageDropzoneContainer = document.getElementById('pdf-to-image-dropzone-container');
    const pdfToImageDropzone = document.getElementById('pdf-to-image-dropzone');
    const pdfToImageInput = document.getElementById('pdf-to-image-input') as HTMLInputElement;
    const pdfToImageBrowseBtn = document.getElementById('pdf-to-image-browse-btn');
    const pdfToImageOptionsContainer = document.getElementById('pdf-to-image-options-container');
    const pdfToImageFileNameEl = document.getElementById('pdf-to-image-file-name');
    const pdfToImageClearBtn = document.getElementById('pdf-to-image-clear-btn');
    const pdfToImageActionBtn = document.getElementById('pdf-to-image-action-btn') as HTMLButtonElement;
    const pdfToImageResultEl = document.getElementById('pdf-to-image-result');
    const pdfToImageToolContainer = document.querySelector('#pdf-to-image-tool-section .tool-container') as HTMLElement;

    let pdfToImageFile: File | null = null;

    function resetPdfToImageTool() {
        pdfToImageFile = null;
        if (pdfToImageInput) pdfToImageInput.value = '';
        
        if (pdfToImageDropzoneContainer) pdfToImageDropzoneContainer.style.display = 'block';
        if (pdfToImageOptionsContainer) pdfToImageOptionsContainer.style.display = 'none';
        if (pdfToImageActionBtn) pdfToImageActionBtn.disabled = true;
        if (pdfToImageResultEl) {
            pdfToImageResultEl.style.display = 'none';
            pdfToImageResultEl.innerHTML = '';
        }
    }

    function handlePdfToImageFile(file: File | undefined) {
        if (!file || file.type !== 'application/pdf') {
            alert('Please select a valid PDF file.');
            return;
        }
        pdfToImageFile = file;

        if (!pdfToImageDropzoneContainer || !pdfToImageOptionsContainer || !pdfToImageFileNameEl || !pdfToImageActionBtn) return;

        pdfToImageDropzoneContainer.style.display = 'none';
        pdfToImageOptionsContainer.style.display = 'block';
        pdfToImageFileNameEl.textContent = pdfToImageFile.name;
        pdfToImageActionBtn.disabled = false;
    }
    
    if (pdfToImageDropzone && pdfToImageInput) {
        pdfToImageDropzone.addEventListener('click', () => pdfToImageInput.click());
        
        pdfToImageDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            pdfToImageDropzone.classList.add('dragover');
        });

        pdfToImageDropzone.addEventListener('dragleave', () => {
            pdfToImageDropzone.classList.remove('dragover');
        });

        pdfToImageDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            pdfToImageDropzone.classList.remove('dragover');
            if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
                handlePdfToImageFile(e.dataTransfer.files[0]);
            }
        });
    }
    
    if (pdfToImageBrowseBtn && pdfToImageInput) {
        pdfToImageBrowseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            pdfToImageInput.click();
        });
    }

    if (pdfToImageInput) {
        pdfToImageInput.addEventListener('change', () => {
            if (pdfToImageInput.files && pdfToImageInput.files.length > 0) {
                handlePdfToImageFile(pdfToImageInput.files[0]);
            }
        });
    }

    if (pdfToImageClearBtn) {
        pdfToImageClearBtn.addEventListener('click', resetPdfToImageTool);
    }

    if (pdfToImageActionBtn) {
        pdfToImageActionBtn.addEventListener('click', async () => {
            if (!pdfToImageResultEl || !pdfToImageFile) return;

            showToolLoadingOverlay(pdfToImageToolContainer, 'Converting to images...');
            pdfToImageResultEl.style.display = 'none';
            pdfToImageActionBtn.disabled = true;

            await new Promise(resolve => setTimeout(resolve, 2500)); // Simulate conversion

            const format = (document.querySelector('input[name="pdf-to-image-format"]:checked') as HTMLInputElement).value;
            const originalName = pdfToImageFile.name.replace(/\.pdf$/i, '');
            const downloadName = `${originalName}_images.zip`;

            hideToolLoadingOverlay(pdfToImageToolContainer);
            pdfToImageResultEl.style.display = 'block';
            pdfToImageResultEl.innerHTML = `
                <p>✅ PDF converted to ${format.toUpperCase()} images successfully!</p>
                <p>Your images are ready for download as a ZIP file.</p>
                <a href="#" download="${downloadName}" class="btn">Download Images (.zip)</a>
            `;
        });
    }
    
    // --- AI Image Editor Tool Logic ---
    const aiImageEditorDropzoneContainer = document.getElementById('ai-image-editor-dropzone-container');
    const aiImageEditorDropzone = document.getElementById('ai-image-editor-dropzone');
    const aiImageEditorInput = document.getElementById('ai-image-editor-input') as HTMLInputElement;
    const aiImageEditorBrowseBtn = document.getElementById('ai-image-editor-browse-btn');
    const aiImageEditorOptionsContainer = document.getElementById('ai-image-editor-options-container');
    const aiImageEditorOriginalPreview = document.getElementById('ai-image-editor-original-preview') as HTMLImageElement;
    const aiImageEditorResultPreview = document.getElementById('ai-image-editor-result-preview') as HTMLImageElement;
    const aiImageEditorResultPlaceholder = document.getElementById('ai-image-editor-result-placeholder');
    const aiImageEditorPrompt = document.getElementById('ai-image-editor-prompt') as HTMLInputElement;
    const aiImageEditorError = document.getElementById('ai-image-editor-error');
    const aiImageEditorActionBtn = document.getElementById('ai-image-editor-action-btn') as HTMLButtonElement;
    const aiImageEditorClearBtn = document.getElementById('ai-image-editor-clear-btn');
    const aiImageEditorResultControls = document.getElementById('ai-image-editor-result-controls');
    const aiImageEditorDownloadLink = document.getElementById('ai-image-editor-download-link') as HTMLAnchorElement;
    const quickEditsContainer = document.querySelector('.quick-edits-chips');
    const toolContainerForImageEditor = document.querySelector('#ai-image-editor-tool-section .tool-container') as HTMLElement;

    let aiImageEditorFile: File | null = null;
    let currentResultBlob: Blob | null = null;

    function resetAiImageEditor() {
        aiImageEditorFile = null;
        currentResultBlob = null;
        if (aiImageEditorInput) aiImageEditorInput.value = '';
        if (aiImageEditorDropzoneContainer) aiImageEditorDropzoneContainer.style.display = 'block';
        if (aiImageEditorOptionsContainer) aiImageEditorOptionsContainer.style.display = 'none';
        if (aiImageEditorResultControls) aiImageEditorResultControls.style.display = 'none';
        if (aiImageEditorPrompt) aiImageEditorPrompt.value = '';
        if (aiImageEditorResultPlaceholder) aiImageEditorResultPlaceholder.style.display = 'flex';
        if (aiImageEditorResultPreview) {
            aiImageEditorResultPreview.src = '';
            aiImageEditorResultPreview.style.display = 'none';
        }
        if(aiImageEditorActionBtn) aiImageEditorActionBtn.disabled = true;
        if(aiImageEditorError) aiImageEditorError.style.display = 'none';
    }

    async function handleAiImageEditorFile(file: File | undefined) {
        if (!file || !file.type.startsWith('image/')) {
            alert('Please select a valid image file (PNG, JPG, WEBP).');
            return;
        }
        aiImageEditorFile = file;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            if (aiImageEditorOriginalPreview) {
                aiImageEditorOriginalPreview.src = e.target?.result as string;
            }
        };
        reader.readAsDataURL(file);

        if (aiImageEditorDropzoneContainer) aiImageEditorDropzoneContainer.style.display = 'none';
        if (aiImageEditorOptionsContainer) aiImageEditorOptionsContainer.style.display = 'block';
        if (aiImageEditorPrompt) aiImageEditorPrompt.value = '';
        if (aiImageEditorResultControls) aiImageEditorResultControls.style.display = 'none';
        if (aiImageEditorResultPlaceholder) aiImageEditorResultPlaceholder.style.display = 'flex';
        if (aiImageEditorResultPreview) {
            aiImageEditorResultPreview.style.display = 'none';
            aiImageEditorResultPreview.src = '';
        }
    }

    async function generateAiImageEdit() {
        if (!aiImageEditorFile || !aiImageEditorPrompt || !aiImageEditorError || !aiImageEditorActionBtn) return;

        const promptText = aiImageEditorPrompt.value.trim();
        if (!promptText) {
            aiImageEditorError.textContent = 'Please enter a text prompt describing your edit.';
            aiImageEditorError.style.display = 'block';
            return;
        }

        aiImageEditorError.style.display = 'none';
        aiImageEditorActionBtn.disabled = true;
        showToolLoadingOverlay(toolContainerForImageEditor, 'Applying AI magic...');
        
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

            const base64Data = await blobToBase64(aiImageEditorFile);
            const imagePart = {
                inlineData: {
                    data: base64Data,
                    mimeType: aiImageEditorFile.type,
                },
            };

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: {
                    parts: [imagePart, { text: promptText }],
                },
                config: {
                    responseModalities: [Modality.IMAGE],
                },
            });
            
            const resultPart = response.candidates?.[0]?.content?.parts?.[0];
            if (resultPart?.inlineData) {
                const resultBase64 = resultPart.inlineData.data;
                const mimeType = resultPart.inlineData.mimeType;
                const byteCharacters = atob(resultBase64);
                const byteNumbers = new Array(byteCharacters.length);
                for (let i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                const byteArray = new Uint8Array(byteNumbers);
                currentResultBlob = new Blob([byteArray], { type: mimeType });
                const imageUrl = URL.createObjectURL(currentResultBlob);

                if (aiImageEditorResultPreview) {
                    aiImageEditorResultPreview.src = imageUrl;
                    aiImageEditorResultPreview.style.display = 'block';
                }
                if (aiImageEditorResultPlaceholder) aiImageEditorResultPlaceholder.style.display = 'none';
                if (aiImageEditorDownloadLink) {
                    aiImageEditorDownloadLink.href = imageUrl;
                    aiImageEditorDownloadLink.download = `edited-${aiImageEditorFile.name}`;
                }
                if (aiImageEditorResultControls) aiImageEditorResultControls.style.display = 'block';
                
                // Allow chaining edits: use the result as the new source
                aiImageEditorFile = new File([currentResultBlob], `edited-${aiImageEditorFile.name}`, { type: mimeType });
                if(aiImageEditorOriginalPreview) aiImageEditorOriginalPreview.src = imageUrl;

            } else {
                throw new Error('No image was generated. The model may not have understood the prompt.');
            }

        } catch (error) {
            console.error("AI Image Editor Error:", error);
            aiImageEditorError.textContent = `An error occurred: ${error.message}`;
            aiImageEditorError.style.display = 'block';
        } finally {
            hideToolLoadingOverlay(toolContainerForImageEditor);
            aiImageEditorActionBtn.disabled = false;
        }
    }

    if (aiImageEditorDropzone) {
        aiImageEditorDropzone.addEventListener('click', () => aiImageEditorInput?.click());
        aiImageEditorDropzone.addEventListener('dragover', (e) => { e.preventDefault(); aiImageEditorDropzone.classList.add('dragover'); });
        aiImageEditorDropzone.addEventListener('dragleave', () => aiImageEditorDropzone.classList.remove('dragover'));
        aiImageEditorDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            aiImageEditorDropzone.classList.remove('dragover');
            if (e.dataTransfer?.files?.[0]) handleAiImageEditorFile(e.dataTransfer.files[0]);
        });
    }
    if (aiImageEditorBrowseBtn) aiImageEditorBrowseBtn.addEventListener('click', (e) => { e.stopPropagation(); aiImageEditorInput?.click(); });
    if (aiImageEditorInput) aiImageEditorInput.addEventListener('change', () => handleAiImageEditorFile(aiImageEditorInput.files?.[0]));
    if (aiImageEditorClearBtn) aiImageEditorClearBtn.addEventListener('click', resetAiImageEditor);

    if (aiImageEditorPrompt) {
        aiImageEditorPrompt.addEventListener('input', () => {
            if(aiImageEditorActionBtn) aiImageEditorActionBtn.disabled = aiImageEditorPrompt.value.trim().length === 0;
            if(aiImageEditorError) aiImageEditorError.style.display = 'none';
        });
    }
    if (aiImageEditorActionBtn) aiImageEditorActionBtn.addEventListener('click', generateAiImageEdit);

    if (quickEditsContainer) {
        quickEditsContainer.addEventListener('click', (e) => {
            const target = e.target as HTMLElement;
            if (target.classList.contains('chip') && target.dataset.prompt) {
                if (aiImageEditorPrompt) {
                    aiImageEditorPrompt.value = target.dataset.prompt;
                    aiImageEditorActionBtn.disabled = false;
                    generateAiImageEdit();
                }
            }
        });
    }
    
    // --- AI Video Generator Tool Logic ---
    const videoGeneratorKeyPrompt = document.getElementById('ai-video-generator-key-prompt');
    const videoGeneratorSelectKeyBtn = document.getElementById('ai-video-generator-select-key-btn');
    const videoGeneratorMainContent = document.getElementById('ai-video-generator-main-content');
    const videoGeneratorDropzoneContainer = document.getElementById('ai-video-generator-dropzone-container');
    const videoGeneratorDropzone = document.getElementById('ai-video-generator-dropzone');
    const videoGeneratorInput = document.getElementById('ai-video-generator-input') as HTMLInputElement;
    const videoGeneratorBrowseBtn = document.getElementById('ai-video-generator-browse-btn');
    const videoGeneratorOptionsContainer = document.getElementById('ai-video-generator-options-container');
    const videoGeneratorPreview = document.getElementById('ai-video-generator-preview') as HTMLImageElement;
    const videoGeneratorPrompt = document.getElementById('ai-video-generator-prompt') as HTMLInputElement;
    const videoGeneratorError = document.getElementById('ai-video-generator-error');
    const videoGeneratorActionBtn = document.getElementById('ai-video-generator-action-btn') as HTMLButtonElement;
    const videoGeneratorClearBtn = document.getElementById('ai-video-generator-clear-btn');
    const videoGeneratorResultContainer = document.getElementById('ai-video-generator-result-container');
    const videoGeneratorResultVideo = document.getElementById('ai-video-generator-result-video') as HTMLVideoElement;
    const videoGeneratorDownloadLink = document.getElementById('ai-video-generator-download-link') as HTMLAnchorElement;
    const videoGeneratorAgainBtn = document.getElementById('ai-video-generator-again-btn');
    const toolContainerForVideoGenerator = document.querySelector('#ai-video-generator-tool-section .tool-container') as HTMLElement;

    let videoGeneratorFile: File | null = null;
    let lastVideoBlobUrl: string | null = null;

    function resetVideoGenerator() {
        if (lastVideoBlobUrl) {
            URL.revokeObjectURL(lastVideoBlobUrl);
        }
        videoGeneratorFile = null;
        lastVideoBlobUrl = null;
        if(videoGeneratorInput) videoGeneratorInput.value = '';
        if(videoGeneratorDropzoneContainer) videoGeneratorDropzoneContainer.style.display = 'block';
        if(videoGeneratorOptionsContainer) videoGeneratorOptionsContainer.style.display = 'none';
        if(videoGeneratorResultContainer) videoGeneratorResultContainer.style.display = 'none';
        if(videoGeneratorPrompt) videoGeneratorPrompt.value = '';
        if(videoGeneratorActionBtn) videoGeneratorActionBtn.disabled = true;
        if(videoGeneratorError) videoGeneratorError.style.display = 'none';
    }

    async function handleVideoGeneratorFile(file: File | undefined) {
        if (!file || !file.type.startsWith('image/')) {
            alert('Please select a valid image file (PNG, JPG, WEBP).');
            return;
        }
        videoGeneratorFile = file;

        const reader = new FileReader();
        reader.onload = (e) => {
            if (videoGeneratorPreview) {
                videoGeneratorPreview.src = e.target?.result as string;
            }
        };
        reader.readAsDataURL(file);

        if (videoGeneratorDropzoneContainer) videoGeneratorDropzoneContainer.style.display = 'none';
        if (videoGeneratorOptionsContainer) videoGeneratorOptionsContainer.style.display = 'block';
        if (videoGeneratorActionBtn) videoGeneratorActionBtn.disabled = false;
    }

    async function generateVideo() {
        if (!videoGeneratorFile || !videoGeneratorActionBtn || !videoGeneratorError || !toolContainerForVideoGenerator) return;

        videoGeneratorActionBtn.disabled = true;
        videoGeneratorError.style.display = 'none';
        showToolLoadingOverlay(toolContainerForVideoGenerator, 'Initializing video generation...');
        
        try {
            const prompt = (videoGeneratorPrompt as HTMLInputElement).value || '';
            const aspectRatio = (document.querySelector('input[name="video-aspect-ratio"]:checked') as HTMLInputElement).value;
            const base64Data = await blobToBase64(videoGeneratorFile);
            
            // IMPORTANT: Create a new instance right before the call to use the latest key.
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            updateToolLoadingOverlayMessage(toolContainerForVideoGenerator, 'Sending request to the model...');
            let operation = await ai.models.generateVideos({
                model: 'veo-3.1-fast-generate-preview',
                prompt: prompt,
                image: {
                    imageBytes: base64Data,
                    mimeType: videoGeneratorFile.type,
                },
                config: {
                    numberOfVideos: 1,
                    resolution: '720p',
                    aspectRatio: aspectRatio as "16:9" | "9:16"
                }
            });

            const messages = [
                "AI is dreaming up your video...",
                "Composing the scenes, frame by frame...",
                "This can take a few minutes. Please wait...",
                "Rendering the final cut...",
                "Almost there! Polishing the pixels..."
            ];
            let messageIndex = 0;
            
            while (!operation.done) {
                updateToolLoadingOverlayMessage(toolContainerForVideoGenerator, messages[messageIndex % messages.length]);
                messageIndex++;
                await new Promise(resolve => setTimeout(resolve, 10000)); // Poll every 10 seconds
                operation = await ai.operations.getVideosOperation({ operation: operation });
            }

            hideToolLoadingOverlay(toolContainerForVideoGenerator);

            if (operation.error) {
                throw new Error(`Operation failed: ${operation.error.message}`);
            }

            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
            if (!downloadLink) {
                throw new Error("Video generation completed, but no video URI was found.");
            }
            
            showToolLoadingOverlay(toolContainerForVideoGenerator, 'Downloading generated video...');
            
            const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
            if (!videoResponse.ok) {
                throw new Error(`Failed to download video file. Status: ${videoResponse.status}`);
            }
            
            const videoBlob = await videoResponse.blob();
            lastVideoBlobUrl = URL.createObjectURL(videoBlob);
            
            if(videoGeneratorResultVideo) videoGeneratorResultVideo.src = lastVideoBlobUrl;
            if(videoGeneratorDownloadLink) videoGeneratorDownloadLink.href = lastVideoBlobUrl;
            
            if(videoGeneratorOptionsContainer) videoGeneratorOptionsContainer.style.display = 'none';
            if(videoGeneratorResultContainer) videoGeneratorResultContainer.style.display = 'block';

        } catch (error) {
            console.error("AI Video Generator Error:", error);
            let errorMessage = `An error occurred: ${error.message}`;
            if (error.message?.includes("Requested entity was not found")) {
                errorMessage = "API Key error. The selected key may be invalid or lack permissions. Please select a different key and try again.";
                // Reset API key state and force re-selection
                if (videoGeneratorKeyPrompt) videoGeneratorKeyPrompt.style.display = 'block';
                if (videoGeneratorMainContent) videoGeneratorMainContent.style.display = 'none';
            }
            if(videoGeneratorError) {
                videoGeneratorError.textContent = errorMessage;
                videoGeneratorError.style.display = 'block';
            }
        } finally {
            hideToolLoadingOverlay(toolContainerForVideoGenerator);
            if(videoGeneratorActionBtn) videoGeneratorActionBtn.disabled = false;
        }
    }

    if(videoGeneratorSelectKeyBtn) {
        videoGeneratorSelectKeyBtn.addEventListener('click', async () => {
            try {
                await window.aistudio.openSelectKey();
                // Assume success and show tool
                if (videoGeneratorKeyPrompt) videoGeneratorKeyPrompt.style.display = 'none';
                if (videoGeneratorMainContent) videoGeneratorMainContent.style.display = 'block';
            } catch (e) {
                console.error("Could not open API key selection dialog", e);
                 if(videoGeneratorError) {
                    videoGeneratorError.textContent = 'Could not open the API key selection dialog. Please refresh and try again.';
                    videoGeneratorError.style.display = 'block';
                 }
            }
        });
    }

    if (videoGeneratorDropzone) {
        videoGeneratorDropzone.addEventListener('click', () => videoGeneratorInput?.click());
        videoGeneratorDropzone.addEventListener('dragover', (e) => { e.preventDefault(); videoGeneratorDropzone.classList.add('dragover'); });
        videoGeneratorDropzone.addEventListener('dragleave', () => videoGeneratorDropzone.classList.remove('dragover'));
        videoGeneratorDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            videoGeneratorDropzone.classList.remove('dragover');
            if (e.dataTransfer?.files?.[0]) handleVideoGeneratorFile(e.dataTransfer.files[0]);
        });
    }

    if (videoGeneratorBrowseBtn) videoGeneratorBrowseBtn.addEventListener('click', (e) => { e.stopPropagation(); videoGeneratorInput?.click(); });
    if (videoGeneratorInput) videoGeneratorInput.addEventListener('change', () => handleVideoGeneratorFile(videoGeneratorInput.files?.[0]));
    if (videoGeneratorClearBtn) videoGeneratorClearBtn.addEventListener('click', resetVideoGenerator);
    if (videoGeneratorActionBtn) videoGeneratorActionBtn.addEventListener('click', generateVideo);
    if (videoGeneratorAgainBtn) videoGeneratorAgainBtn.addEventListener('click', resetVideoGenerator);
    
    // Initial State
    updateAllUsageDisplays();
    showSection('home-section'); 
});
